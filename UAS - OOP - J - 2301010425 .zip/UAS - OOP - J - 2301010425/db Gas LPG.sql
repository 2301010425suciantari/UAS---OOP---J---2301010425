/*
SQLyog Ultimate v12.4.3 (64 bit)
MySQL - 10.4.32-MariaDB : Database - rekappengambilangaslpg
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`rekappengambilangaslpg` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `rekappengambilangaslpg`;

/*Table structure for table `pengambilan gas` */

DROP TABLE IF EXISTS `pengambilan gas`;

CREATE TABLE `pengambilan gas` (
  `NO. TRANSAKSI` int(15) NOT NULL AUTO_INCREMENT,
  `PANGKALAN` varchar(25) DEFAULT NULL,
  `SESI` enum('SESI 1','SESI 2') DEFAULT NULL,
  `ALOKASI` varchar(2) DEFAULT NULL,
  `T. KOSONGAN` varchar(3) DEFAULT NULL,
  `QTY PENGAMBILAN` varchar(3) DEFAULT NULL,
  `JAM MASUK` timestamp(6) NULL DEFAULT current_timestamp(6),
  `JAM KELUAR` timestamp(6) NULL DEFAULT current_timestamp(6),
  `STATUS` enum('SELESAI','MENUNGGU') DEFAULT NULL,
  PRIMARY KEY (`NO. TRANSAKSI`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `pengambilan gas` */

insert  into `pengambilan gas`(`NO. TRANSAKSI`,`PANGKALAN`,`SESI`,`ALOKASI`,`T. KOSONGAN`,`QTY PENGAMBILAN`,`JAM MASUK`,`JAM KELUAR`,`STATUS`) values 
(1,'suciantari','SESI 1','20','20','20',NULL,'2025-06-28 10:54:26.000000',NULL),
(2,'adi','SESI 1','12','12','12','2025-06-28 10:56:38.000000','2025-06-28 06:56:41.000000','SELESAI'),
(3,'sasa','SESI 1','21','21','21','2025-06-28 10:58:15.000000','2025-06-28 10:58:21.000000','SELESAI');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
