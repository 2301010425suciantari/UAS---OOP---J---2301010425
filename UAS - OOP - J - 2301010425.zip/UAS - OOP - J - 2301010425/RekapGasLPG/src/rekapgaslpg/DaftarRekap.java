/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package rekapgaslpg;
import javax.swing.table.DefaultTableModel;
import static rekapgaslpg.DBkoneksi.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
/**
 *
 * @author SUCIANTARI CANTIK 2301010425 / 28 JUNI 2025
 */
public class DaftarRekap extends javax.swing.JFrame {
    
    DefaultTableModel DM = new DefaultTableModel();

    /**
     * Creates new form DaftarRekap
     * @throws java.sql.SQLException
     */
    public DaftarRekap()throws SQLException {
        initComponents();
        TM.setModel(DM);
        DM.addColumn("NOMOR");
        DM.addColumn("PANGKALAN");
        DM.addColumn("SESI");
        DM.addColumn("ALOKASI");
        DM.addColumn("QTY KOSONGAN");
        DM.addColumn("QTY ISIAN");
        DM.addColumn("JAM DATANG");
        DM.addColumn("STATUS");
        
        txSESI.add("Sesi 1");
        txSESI.add("Sesi 2");
        
        txSTATUS.add("Selesai");
        txSTATUS.add("Menunggu");


        
        cleartextField();
        this.ListDataTable();
        tombol(false);
        cBARU.setEnabled(true);
        fieldIsian(false);
        txNO.setEditable(false);
    }
    
    private String generateAutoCode() throws SQLException {
    Connection cnn = koneksi();
    String autoCode = "1";

        if (!cnn.isClosed()) {
            PreparedStatement PS = cnn.prepareStatement("SELECT NOMOR FROM gas ORDER BY NOMOR ASC");
            ResultSet RS = PS.executeQuery();

            int i = 1;
            while (RS.next()) {
                String current = RS.getString("NOMOR");
                if (!current.equals(String.valueOf(i))) {
                    break; // jika ditemukan lubang, isi di sana
                }
                i++;
            }
            autoCode = String.valueOf(i);
            cnn.close();
        }

        return autoCode;
    }
    
    private void reorderCode() throws SQLException {
    Connection cnn = koneksi();

        if (!cnn.isClosed()) {
            PreparedStatement select = cnn.prepareStatement("SELECT * FROM gas ORDER BY NOMOR ASC");
            ResultSet rs = select.executeQuery();

            int newCode = 1;
            while (rs.next()) {
                String oldCode = rs.getString("NOMOR");

                PreparedStatement update = cnn.prepareStatement("UPDATE gas SET NOMOR=? WHERE NOMOR=?");
                update.setString(1, String.valueOf(newCode));
                update.setString(2, oldCode);
                update.executeUpdate();

                newCode++;
            }

            cnn.close();
        }
    }
    private void storedta ()throws SQLException{
        if (!txNO.getText().equals("")){
            
            Connection cnn = koneksi();
            if(!cnn.isClosed()){
                PreparedStatement PS = cnn.prepareStatement("INSERT INTO gas (`NOMOR`, `PANGKALAN`, `SESI`, `ALOKASI`, `QTY KOSONGAN`,`QTY ISIAN`, `JAM DATANG`, `STATUS` ) VALUES (?,?,?,?,?,?,?,?);");

                PS.setString(1, txNO.getText());
                PS.setString(2, txNAMA.getText());
                PS.setString(3, txSESI.getSelectedItem());
                PS.setString(4, txALOKASI.getText());
                PS.setString(5, txKOSONG.getText());
                PS.setString(6, txISI.getText());
                
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String jamDatangFormatted = sdf.format((Date) txJAM.getValue());

                PS.setString(7, jamDatangFormatted); 
                PS.setString(8, txSTATUS.getSelectedItem());
                PS.executeUpdate();
                cnn.close();
            }
        }
    }
    private void updatedta ()throws SQLException{
        Connection cnn = koneksi();
        if(!cnn.isClosed()){
            PreparedStatement PS = cnn.prepareStatement("UPDATE gas SET `PANGKALAN`=?, `SESI`=?, `ALOKASI`=?, `QTY KOSONGAN`=?,`QTY ISIAN`=?, `JAM DATANG`=?, `STATUS`=? WHERE `NOMOR` = ?;");
            
            PS.setString(1, txNAMA.getText());
            PS.setString(2, txSESI.getSelectedItem());
            PS.setString(3, txALOKASI.getText());
            PS.setString(4, txKOSONG.getText());
            PS.setString(5, txISI.getText());
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String jamDatangFormatted = sdf.format((Date) txJAM.getValue());

            PS.setString(6, jamDatangFormatted); 
            PS.setString(7, txSTATUS.getSelectedItem());
            PS.setString(8, txNO.getText());
            PS.executeUpdate();
            cnn.close();
            
            
        }
    }
    private void destroydta (String no) throws SQLException{
        //String sql = "DELETE FROM mhs WHERE NIM = '?';";
        Connection cnn = koneksi();
        if(!cnn.isClosed()){
            PreparedStatement PS = cnn.prepareStatement("DELETE FROM gas WHERE NOMOR = ?;");
            PS.setString(1, no);
            PS.executeUpdate();
            cnn.close();
        }
    }
    private void tombol (boolean opsi){
        cBARU.setEnabled(opsi);
        cUBAH.setEnabled(opsi);
        cHAPUS.setEnabled(opsi);
    }
    private void fieldIsian(boolean opsi){
        txNO.setEnabled(opsi);
        txNAMA.setEnabled(opsi);
        txSESI.setEnabled(opsi);
        txALOKASI.setEnabled(opsi);
        txKOSONG.setEnabled(opsi);
        txISI.setEnabled(opsi);
        txJAM.setEnabled(opsi);
        txSTATUS.setEnabled(opsi);
    }
    private void cleartextField(){
        txNO.setText("");
        txNAMA.setText("");
        txSESI.select(0);
        txALOKASI.setText("");
        txKOSONG.setText("");
        txISI.setText("");
        txJAM.setValue(new Date()); 
        txSTATUS.select(0);
    }
    private void ListDataTable () throws SQLException{
        Connection cnn = koneksi();
        
        DM.getDataVector().removeAllElements();
        DM.fireTableDataChanged();
        
        if (!cnn.isClosed()) {
            PreparedStatement PS= cnn.prepareStatement("SELECT * FROM gas;");
            ResultSet RS = PS.executeQuery();
            
            while (RS.next()){                
                Object[] dta = new Object[8];
                dta[0]=RS.getString("NOMOR");
                dta[1]=RS.getString("PANGKALAN");
                dta[2]=RS.getString("SESI");
                dta[3]=RS.getString("ALOKASI");
                dta[4]=RS.getString("QTY KOSONGAN");
                dta[5]=RS.getString("QTY ISIAN");
                dta[6]=RS.getTime("JAM DATANG");
                dta[7]=RS.getString("STATUS");
                
                DM.addRow(dta);
            }
            cnn.close();
            
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TM = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txNO = new javax.swing.JTextField();
        txNAMA = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txALOKASI = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txKOSONG = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txISI = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txSESI = new java.awt.Choice();
        txSTATUS = new java.awt.Choice();
        cBARU = new javax.swing.JButton();
        cUBAH = new javax.swing.JButton();
        cHAPUS = new javax.swing.JButton();
        cTUTUP = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txJAM = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Rubik", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 153, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("REKAPAN DATA GAS LPG PT. DEVANTA PUTRA PERKASA");

        TM.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        TM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NOMOR ", "PANGKALAN", "SESI", "ALOKASI", "JAM DATANG", "KOSONGAN", "ISIAN", "STATUS"
            }
        ));
        TM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TMMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TM);

        jLabel2.setFont(new java.awt.Font("Arial", 2, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 0));
        jLabel2.setText("Edit Data View");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("Nomor");

        txNO.setText("jTextField1");

        txNAMA.setText("jTextField1");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel4.setText("Nama Pangkalan");

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel5.setText("Sesi Pengambilan");

        txALOKASI.setText("jTextField1");

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel6.setText("Alokasi");

        txKOSONG.setText("jTextField1");

        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel7.setText("Qty Kosongan");

        txISI.setText("jTextField1");

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel8.setText("Qty Isian");

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel9.setText("Status");

        cBARU.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        cBARU.setText("ADD");
        cBARU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cBARUActionPerformed(evt);
            }
        });

        cUBAH.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        cUBAH.setText("UPDATE");
        cUBAH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cUBAHActionPerformed(evt);
            }
        });

        cHAPUS.setBackground(new java.awt.Color(204, 0, 0));
        cHAPUS.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        cHAPUS.setText("DELETE");
        cHAPUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cHAPUSActionPerformed(evt);
            }
        });

        cTUTUP.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        cTUTUP.setText("CLOSE");
        cTUTUP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cTUTUPActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel10.setText("Jam Datang");

        txJAM.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, null, java.util.Calendar.SECOND));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(106, 106, 106))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txNO, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(528, 528, 528)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txJAM, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cBARU, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cUBAH, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cHAPUS, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txALOKASI, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txKOSONG)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(cTUTUP, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txISI)
                                    .addComponent(txSTATUS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txNAMA)
                                .addGap(237, 237, 237)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(jLabel5))
                            .addComponent(txSESI, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txJAM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txNO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txSESI, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txNAMA, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txALOKASI, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txISI, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txKOSONG, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9))
                    .addComponent(txSTATUS, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cBARU, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cUBAH, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cHAPUS, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cTUTUP, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void cBARUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cBARUActionPerformed
        if (cBARU.getText().equals("ADD")){
            cBARU.setText("SAVE");
            cTUTUP.setText("CANCEL");
            cUBAH.setEnabled(false);
            cHAPUS.setEnabled(false);
            cleartextField();
            fieldIsian(true);
            
            try {
                txNO.setText(generateAutoCode());
            } catch (SQLException ex) {
                Logger.getLogger(DaftarRekap.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }else{
            cBARU.setText("ADD");
            cTUTUP.setText("CLOSE");
            try {
                storedta();
                ListDataTable();
            } catch (SQLException ex) {
                Logger.getLogger(DaftarRekap.class.getName()).log(Level.SEVERE, null, ex);
            }
            cleartextField();
            fieldIsian(false);
        }
    }//GEN-LAST:event_cBARUActionPerformed

    private void cUBAHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cUBAHActionPerformed
        if (cUBAH.getText().equals("UPDATE")){
            cUBAH.setText("SAVE");
            cTUTUP.setText("CANCEL");
            cBARU.setEnabled(false);
            cHAPUS.setEnabled(false);
            fieldIsian(true);
            txNO.setEditable(false);
            txNO.setEditable(false);
            txJAM.setEnabled(false);
            
            
        }else{
            cUBAH.setText("UPDATE");
            cTUTUP.setText("CLOSE");
            try {
                updatedta();
                ListDataTable();
            } catch (SQLException ex) {
                Logger.getLogger(DaftarRekap.class.getName()).log(Level.SEVERE, null, ex);
            }
            cleartextField();
            fieldIsian(false);
            cBARU.setEnabled(true);
            cUBAH.setEnabled(false);
        }
    }//GEN-LAST:event_cUBAHActionPerformed

    private void cHAPUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cHAPUSActionPerformed
        if (cHAPUS.getText().equals("DELETE")){
            String no = txNO.getText();

            
            
            int jwb = JOptionPane.showOptionDialog(this,
                "Yakin akan Menghapus data dengan nomor transaksi: "+ no,
                "Konfirmasi Hapus Data",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.ERROR_MESSAGE,
                null, null, null);
            if (jwb == JOptionPane.YES_OPTION){
                try {
                    destroydta(no);
                    ListDataTable();
                } catch (SQLException ex) {
                    Logger.getLogger(DaftarRekap.class.getName()).log(Level.SEVERE, null, ex);
                }
                cleartextField();
                fieldIsian(false);
                cBARU.setEnabled(true);
                cUBAH.setEnabled(false);
                cHAPUS.setEnabled(false);

            }
        }

    }//GEN-LAST:event_cHAPUSActionPerformed

    private void cTUTUPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cTUTUPActionPerformed
        if (cTUTUP.getText().equals("CLOSE")){
            int jwb = JOptionPane.showOptionDialog(this,
                "Yakin akan menutup aplikasi",
                "Konfirmasi Tutup Aplikasi",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.ERROR_MESSAGE,
                null, null, null);
            if(jwb == JOptionPane.YES_OPTION){
                System.exit(0);
            }
        }else{
            cTUTUP.setText("CLOSE");
            cBARU.setText("NEW");
            cUBAH.setText("UPDATE");
            cBARU.setEnabled(true);
            cHAPUS.setEnabled(false);
            cUBAH.setEnabled(false);
            cleartextField();
            fieldIsian(false);
        }
    }//GEN-LAST:event_cTUTUPActionPerformed

    private void TMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TMMouseClicked
        txNO.setText(TM.getValueAt(TM.getSelectedRow(), 0).toString());

        txNAMA.setText(TM.getValueAt(TM.getSelectedRow(), 1).toString());
        txSESI.select(TM.getValueAt(TM.getSelectedRow(), 2).toString());
        txALOKASI.setText(TM.getValueAt(TM.getSelectedRow(), 3).toString());
        txKOSONG.setText(TM.getValueAt(TM.getSelectedRow(), 4).toString());
        txISI.setText(TM.getValueAt(TM.getSelectedRow(), 5).toString());
        
        
        txJAM.setModel(new javax.swing.SpinnerDateModel(new java.util.Date(), null, null, java.util.Calendar.SECOND));
        //txJAM.setValue(TM.getValueAt(TM.getSelectedRow(), 6).equals(evt));
        txSTATUS.select(TM.getValueAt(TM.getSelectedRow(), 7).toString());
        
        
        cUBAH.setEnabled(true);
        cHAPUS.setEnabled(true);// TODO add your handling code here:
    }//GEN-LAST:event_TMMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DaftarRekap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DaftarRekap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DaftarRekap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DaftarRekap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new DaftarRekap().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(DaftarRekap.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TM;
    private javax.swing.JButton cBARU;
    private javax.swing.JButton cHAPUS;
    private javax.swing.JButton cTUTUP;
    private javax.swing.JButton cUBAH;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txALOKASI;
    private javax.swing.JTextField txISI;
    private javax.swing.JSpinner txJAM;
    private javax.swing.JTextField txKOSONG;
    private javax.swing.JTextField txNAMA;
    private javax.swing.JTextField txNO;
    private java.awt.Choice txSESI;
    private java.awt.Choice txSTATUS;
    // End of variables declaration//GEN-END:variables
}
