/*
SQLyog Ultimate v12.4.3 (64 bit)
MySQL - 10.4.32-MariaDB : Database - rekappengambilangaslpg
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`rekappengambilangaslpg` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `rekappengambilangaslpg`;

/*Table structure for table `gas` */

DROP TABLE IF EXISTS `gas`;

CREATE TABLE `gas` (
  `NOMOR` int(15) NOT NULL AUTO_INCREMENT,
  `PANGKALAN` varchar(25) DEFAULT NULL,
  `SESI` enum('SESI 1','SESI 2') DEFAULT NULL,
  `ALOKASI` varchar(2) DEFAULT NULL,
  `QTY KOSONGAN` varchar(3) DEFAULT NULL,
  `QTY ISIAN` varchar(3) DEFAULT NULL,
  `JAM DATANG` datetime DEFAULT NULL,
  `STATUS` enum('SELESAI','MENUNGGU') DEFAULT NULL,
  PRIMARY KEY (`NOMOR`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `gas` */

insert  into `gas`(`NOMOR`,`PANGKALAN`,`SESI`,`ALOKASI`,`QTY KOSONGAN`,`QTY ISIAN`,`JAM DATANG`,`STATUS`) values 
(1,'budi','SESI 1','20','20','20','2025-06-30 21:23:21','SELESAI'),
(2,'saya','SESI 2','1','1','12','2025-06-30 21:36:33','SELESAI'),
(3,'suciantari','SESI 1','60','60','40','2025-06-30 21:42:01','SELESAI'),
(4,'Nadri','SESI 2','50','50','50','2025-06-30 22:03:56','SELESAI');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
